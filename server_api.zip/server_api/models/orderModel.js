import { beginTransaction, commitTransaction, rollbackTransaction, execute } from "../config/db.js";
 
export default class orderModel {
    /**
     * TỰ ĐỘNG TÍNH PHÍ SHIP THEO TỈNH THÀNH (Bỏ qua lỗi thiếu bảng database)
     */
    static async getShippingFee(city) {
        if (!city) return 30000;
        const normalizedCity = city.toLowerCase();
        
        if (normalizedCity.includes("hồ chí minh") || normalizedCity.includes("hcm")) {
            return 20000; // Nội thành HCM: 20k
        } else if (normalizedCity.includes("hà nội")) {
            return 35000; // Hà Nội: 35k
        }
        return 30000; // Các tỉnh thành khác mặc định 30k
    }

    /**
     * HÀM ĐẶT ĐƠN THUÊ ĐỒ CẮM TRẠI ĐỈNH CAO (GIẢI QUYẾT XUNG ĐỘT LỊCH TRÌNH CỦA CÔ GIÁO)
     * Logic: Cọc cố định + Chiết khấu đơn + Kiểm tra trùng ngày thuê giữa Người A, C, D
     */
    static async checkout(userId, shippingData, couponCode, payment_method, orderItems, is_buy_now) {
        const { beginTransaction, commitTransaction, rollbackTransaction, execute } = await import("../config/db.js");
        const conn = await beginTransaction(); 

        try {
            if (!orderItems || orderItems.length === 0) throw new Error("Danh sách sản phẩm trống!");

            // 1. Tính toán số ngày thuê đồ từ dữ liệu đặt đơn
            const dateThue = new Date(shippingData.NgayThue);
            const dateTra = new Date(shippingData.NgayTra);
            const rentalDays = Math.ceil(Math.abs(dateTra - dateThue) / (1000 * 60 * 60 * 24)) || 1; 

            let tongTienThueGoc = 0;
            let tongTienCocCoDinh = 0;

            // 2. VÒNG LẶP KIỂM TRA TỪNG SẢN PHẨM TRONG GIỎ HÀNG
            for (const item of orderItems) {
                const productId = item.product_id || item.product_variant_id;
                
                // Lấy thông tin Giá thuê, Tiền cọc và Tổng số lượng gốc trong kho
                const [prodRows] = await conn.execute(
                    "SELECT TenSanPham, GiaThueTheoNgay, TienCoc, SoLuongTon FROM sanpham WHERE MaSanPham = ? FOR UPDATE", 
                    [productId]
                );

                if (prodRows.length === 0) throw new Error(`Không tìm thấy sản phẩm có ID: ${productId}`);
                const product = prodRows[0];

                // --- 🛡️ THUẬT TOÁN ĐỈNH CAO: KIỂM TRA XUNG ĐỘT LỊCH TRÌNH ---
                const [conflictRows] = await conn.execute(
                    `SELECT SUM(ct.SoLuong) AS TotalRented
                     FROM chitietdonthue ct
                     JOIN donthue d ON ct.MaDonThue = d.MaDonThue
                     WHERE ct.MaSanPham = ?
                       AND d.TrangThaiDon != 'cancelled'
                       AND d.NgayBatDau <= ? 
                       AND d.NgayKetThuc >= ?`,
                    [productId, shippingData.NgayTra, shippingData.NgayThue]
                );

                const totalRented = conflictRows[0].TotalRented ? parseInt(conflictRows[0].TotalRented) : 0;
                const availableQuantity = product.SoLuongTon - totalRented;

                if (availableQuantity < item.quantity) {
                    throw new Error(
                        `Sản phẩm "${product.TenSanPham}" đã hết hàng hoặc không đủ số lượng trong khoảng thời gian từ ${shippingData.NgayThue} đến ${shippingData.NgayTra}! ` +
                        `(Hệ thống còn trống: ${availableQuantity} cái, bạn yêu cầu: ${item.quantity} cái). Vui lòng chọn ngày khác!`
                    );
                }
                // ------------------------------------------------------------------------

                tongTienThueGoc += parseFloat(product.GiaThueTheoNgay) * item.quantity * rentalDays;
                tongTienCocCoDinh += parseFloat(product.TienCoc) * item.quantity;
            }

            // 3. ƯU ĐÃI GIẢM GIÁ THEO NGÀY THUÊ (Style App Mobile)
            let discountRate = 0; 
            if (rentalDays >= 3 && rentalDays <= 6) {
                discountRate = 0.1; // Thuê từ 3 - 6 ngày: Giảm 10%
            } else if (rentalDays >= 7) {
                discountRate = 0.2; // Thuê từ 7 ngày trở lên: Giảm 20%
            }
            const tienThueSauGiam = tongTienThueGoc * (1 - discountRate);

            // 4. LOGIC TÍNH % HOA HỒNG THEO SỐ NGÀY THUÊ CỦA CÔ GIÁO
            let PhanTramHoaHong = 0;
            if (rentalDays < 3) {
                PhanTramHoaHong = 5;  
            } else if (rentalDays >= 3 && rentalDays <= 7) {
                PhanTramHoaHong = 10; 
            } else {
                PhanTramHoaHong = 15; 
            }
            let TienHoaHong = tienThueSauGiam * (PhanTramHoaHong / 100);

            // Phí giao hàng
            const shippingFee = await this.getShippingFee(shippingData.city);
            const tongThanhToan = tienThueSauGiam + shippingFee;

            const DiaChiGiaoHang = `${shippingData.address}, ${shippingData.city}`;

            // 5. LƯU THÔNG TIN VÀO BẢNG donthue
            const insertOrderSql = `
                INSERT INTO donthue (
                    MaKhachThue, NgayBatDau, NgayKetThuc, PhuongThucGiaoNhan, 
                    DiaChiGiaoHang, GhiChu, NgayGui, TongTienThue, 
                    TongTienCoc, PhiGiaoHang, TrangThaiDon, NgayTao, 
                    PhanTramHoaHong, TienHoaHong
                ) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, 'pending', NOW(), ?, ?)
            `;
            
            const [orderResult] = await conn.execute(insertOrderSql, [
                userId, shippingData.NgayThue, shippingData.NgayTra, payment_method, DiaChiGiaoHang,
                shippingData.note || '', tongThanhToan, tongTienCocCoDinh, shippingFee, PhanTramHoaHong, TienHoaHong
            ]);

            const newOrderId = orderResult.insertId;

            // 6. LƯU CHI TIẾT VÀO BẢNG chitietdonthue
            for (const item of orderItems) {
                const productId = item.product_id || item.product_variant_id;
                
                await conn.execute(
                    `INSERT INTO chitietdonthue (MaDonThue, MaSanPham, SoLuong) VALUES (?, ?, ?)`,
                    [newOrderId, productId, item.quantity]
                );
            }

            // Dọn sạch giỏ hàng nếu đặt đơn từ giỏ hàng thành công
            if (!is_buy_now) {
                await conn.execute("DELETE FROM giohang WHERE MaNguoiDung = ?", [userId]); 
            }

            await commitTransaction(conn);
            return newOrderId;

        } catch (error) {
            await rollbackTransaction(conn);
            throw error; 
        }
    }

    static async cancelOrder(order_id){
        const conn = await beginTransaction();
        try {
            const [order] = await conn.query("SELECT TrangThaiDon AS status FROM donthue WHERE MaDonThue = ?", [order_id]);
            if (order.length === 0) throw new Error("Không tìm thấy đơn thuê");
            
            if (order[0].status !== 'pending') {
                throw new Error('Chỉ có thể hủy đơn khi đang chờ duyệt. Đơn của bạn đã được xử lý!');
            }

            await conn.query("UPDATE donthue SET TrangThaiDon = 'cancelled' WHERE MaDonThue = ?", [order_id]);
            
            await commitTransaction(conn);
            return true;
        } catch(error){
            await rollbackTransaction(conn);
            throw new Error('Lỗi hủy đơn thuê: ' + error.message);
        }
    }

    static async orderStatus(order_ID){
        try{
            const [result] = await execute('SELECT TrangThaiDon AS status FROM donthue WHERE MaDonThue = ? LIMIT 1', [order_ID]);
            return result[0] ?? null;
        }catch(error){
            throw new Error('Lỗi lấy trạng thái: ' + error.message);
        }
    }

    static async approveOrders(order_ID, status){
        try{
            const [result] = await execute('UPDATE donthue SET TrangThaiDon = ? WHERE MaDonThue = ?', [status, order_ID]);
            return result.affectedRows > 0;
        } catch(error){
            throw new Error('Lỗi cập nhật đơn: ' + error.message);
        }
    }

    static async getOrderDetail(order_ID){
        try {
            const [orderDetail] = await execute(`
                SELECT 
                    d.MaDonThue, d.MaKhachThue, d.DiaChiGiaoHang, d.PhuongThucGiaoNhan, d.GhiChu, 
                    d.NgayBatDau, d.NgayKetThuc, d.NgayTraThucTe,
                    d.TongTienThue, d.TongTienCoc, d.PhiGiaoHang, 
                    d.PhanTramHoaHong, d.TienHoaHong, d.SoTienCocHoanTra, d.TienPhat,
                    d.TrangThaiDon as status, d.TrangThaiGiaoHang, d.NgayTao,
                    ct.MaChiTietDon, ct.MaSanPham, ct.SoLuong,
                    sp.TenSanPham, sp.GiaThueTheoNgay
                FROM donthue d
                JOIN chitietdonthue ct ON d.MaDonThue = ct.MaDonThue 
                JOIN sanpham sp ON ct.MaSanPham = sp.MaSanPham
                WHERE d.MaDonThue = ?
            `, [order_ID]);
            return orderDetail;
        } catch(error){
            throw new Error('Lỗi lấy chi tiết đơn: ' + error.message);
        }
    }

    static async getListOrderByUserID(user_id){
        try {
            const [listOrder] = await execute(`SELECT * FROM donthue WHERE MaKhachThue = ? ORDER BY NgayTao DESC`, [user_id]);
            return listOrder;
        } catch(error){
            throw new Error('Lỗi lấy danh sách đơn của khách: ' + error.message);
        }
    }

    static async getAllOrder(){
        try {
            const [orders] = await execute(`SELECT * FROM donthue ORDER BY NgayTao DESC`);
            return orders;
        } catch(error){
            throw new Error("Lỗi lấy tất cả đơn thuê: " + error.message);
        }
    }

    static async returnOrder(order_id, tien_phat_thu_cong, ghi_chu) {
        try {
            const [orders] = await execute(
                'SELECT TongTienCoc, TrangThaiDon, NgayKetThuc, TongTienThue FROM donthue WHERE MaDonThue = ?', 
                [order_id]
            );
            
            if (orders.length === 0) throw new Error("Không tìm thấy đơn thuê");
            const order = orders[0];
            
            if (order.TrangThaiDon === 'cancelled' || order.TrangThaiDon === 'completed') {
                 throw new Error("Đơn hàng này đã bị hủy hoặc đã hoàn tất trước đó!");
            }

            const ngayHenTra = new Date(order.NgayKetThuc);
            const ngayThucTra = new Date(); 

            let soNgayTre = 0;
            let tienPhatTre = 0;

            if (ngayThucTra > ngayHenTra) {
                const diffTime = Math.abs(ngayThucTra - ngayHenTra);
                soNgayTre = Math.floor(diffTime / (1000 * 60 * 60 * 24));
            }

            if (soNgayTre > 0) {
                tienPhatTre = soNgayTre * (parseFloat(order.TongTienThue) * 0.1);
            }

            const tongTienPhat = tienPhatTre + (parseFloat(tien_phat_thu_cong) || 0);

            let tienCocHoanTra = parseFloat(order.TongTienCoc) - tongTienPhat;
            if (tienCocHoanTra < 0) tienCocHoanTra = 0; 

            let finalNote = ghi_chu ? ` | Admin: ${ghi_chu}` : '';
            if (soNgayTre > 0) {
                finalNote = `Khách trả trễ ${soNgayTre} ngày (Máy tự phạt: ${tienPhatTre}đ)${finalNote}`;
            }

            const sql = `
                UPDATE donthue
                SET TrangThaiDon = 'completed',
                    TrangThaiGiaoHang = 'đã thu hồi',
                    NgayTraThucTe = NOW(),
                    TienPhat = ?,
                    SoTienCocHoanTra = ?,
                    GhiChu = CONCAT(IFNULL(GhiChu, ''), ?)
                WHERE MaDonThue = ?
            `;
            
            const [result] = await execute(sql, [tongTienPhat, tienCocHoanTra, finalNote, order_id]);
            return result.affectedRows > 0;
            
        } catch (error) {
            throw new Error("Lỗi xử lý trả đồ: " + error.message);
        }
    }

    static async getDashboardStats() {
        try {
            const [totalOrdersRows] = await execute("SELECT COUNT(*) AS total FROM donthue");
            
            const [revenueRows] = await execute(
                "SELECT SUM(TongTienThue) AS total FROM donthue WHERE TrangThaiDon = 'completed'"
            );

            const [totalUsersRows] = await execute(
                "SELECT COUNT(*) AS total FROM NguoiDung WHERE VaiTro = 'user'" 
            );

            const [pendingOrdersRows] = await execute(
                "SELECT COUNT(*) AS total FROM donthue WHERE TrangThaiDon = 'pending'"
            );

            return {
                totalOrders: totalOrdersRows[0].total || 0,
                totalRevenue: revenueRows[0].total || 0,
                totalUsers: totalUsersRows[0].total || 0,
                pendingOrdersToday: pendingOrdersRows[0].total || 0
            };
        } catch (error) {
            throw new Error("Lỗi truy vấn dữ liệu thống kê: " + error.message);
        }
    }
    
    static async getOrdersByCustomerId(customerId) {
        try {
            const query = `
                SELECT * FROM donthue 
                WHERE MaKhachThue = ? 
                ORDER BY MaDonThue DESC
            `;
            const [orders] = await execute(query, [customerId]);
            return orders;
        } catch (error) {
            throw new Error("Lỗi lấy danh sách đơn đã đặt: " + error.message);
        }
    }

    static async getIncomingRequestsForLessor(lessorId) {
        try {
            const query = `
                SELECT DISTINCT 
                    d.MaDonThue, 
                    d.MaKhachThue, 
                    d.TongTienThue, 
                    d.TrangThaiDon, 
                    d.NgayTao,
                    p.TenSanPham,
                    p.MaSanPham
                FROM donthue d
                JOIN chitietdonthue ct ON d.MaDonThue = ct.MaDonThue
                JOIN sanpham p ON ct.MaSanPham = p.MaSanPham
                WHERE p.MaChuSoHuu = ?
                ORDER BY d.MaDonThue DESC
            `;
            const [requests] = await execute(query, [lessorId]);
            return requests;
        } catch (error) {
            throw new Error("Lỗi lấy yêu cầu thuê của chủ đồ: " + error.message);
        }
    }

    static async insertComplaint(orderId, userId, loaiKhieuNai, lyDo, hinhAnh) {
        const { beginTransaction, commitTransaction, rollbackTransaction } = await import("../config/db.js");
        const conn = await beginTransaction();

        try {
            const [orderCheck] = await conn.execute(
                `SELECT dt.MaDonThue 
                 FROM donthue dt
                 JOIN chitietdonthue ctdt ON dt.MaDonThue = ctdt.MaDonThue
                 JOIN sanpham sp ON ctdt.MaSanPham = sp.MaSanPham
                 WHERE dt.MaDonThue = ? AND (dt.MaKhachThue = ? OR sp.MaChuSoHuu = ?)
                 LIMIT 1`,
                [orderId, userId, userId]
            );

            if (orderCheck.length === 0) {
                throw new Error("Không tìm thấy đơn hàng, hoặc bạn không có quyền khiếu nại đơn hàng này!");
            }

            const insertSql = `
                INSERT INTO khieunai 
                (MaDonThue, MaNguoiKhieuNai, LoaiKhieuNai, LyDo, HinhAnhBangChung, TrangThai, NgayKhieuNai)
                VALUES (?, ?, ?, ?, ?, 'Chờ xử lý', NOW())
            `;
            const [complaintResult] = await conn.execute(insertSql, [
                orderId, 
                userId, 
                loaiKhieuNai || 'Lừa đảo / Tráo hàng', 
                lyDo, 
                hinhAnh || null
            ]);

            await conn.execute(
                "UPDATE donthue SET TrangThaiDon = 'disputed' WHERE MaDonThue = ?", 
                [orderId]
            );

            await commitTransaction(conn);
            return complaintResult.insertId;

        } catch (error) {
            await rollbackTransaction(conn);
            throw new Error("Lỗi khi tạo khiếu nại: " + error.message);
        }
    }

    // =========================================================
    // 🛠️ ĐÃ SỬA: ADMIN PHÂN XỬ KHIẾU NẠI + CHUYỂN TIỀN THẬT
    // =========================================================
    static async resolveComplaint(complaintId, adminId, hinhThucId, soTien, noiDung, trangThaiDonMoi) {
        const { beginTransaction, commitTransaction, rollbackTransaction } = await import("../config/db.js");
        const conn = await beginTransaction();

        try {
            const systemWalletId = 5;

            // ĐÃ SỬA: Lấy TongTienThue, TongTienCoc từ donthue và MaChuSoHuu từ sanpham
            const [complaintRows] = await conn.execute(
                `SELECT kn.MaDonThue, dt.MaKhachThue, dt.TongTienThue, dt.TongTienCoc, sp.MaChuSoHuu AS MaChuDo
                 FROM khieunai kn
                 JOIN donthue dt ON kn.MaDonThue = dt.MaDonThue
                 JOIN chitietdonthue ct ON dt.MaDonThue = ct.MaDonThue
                 JOIN sanpham sp ON ct.MaSanPham = sp.MaSanPham
                 WHERE kn.MaKhieuNai = ? LIMIT 1 FOR UPDATE`, 
                [complaintId]
            );

            if (complaintRows.length === 0) {
                throw new Error("Không tìm thấy dữ liệu khiếu nại này!");
            }

            const data = complaintRows[0];
            const orderId = data.MaDonThue;
            const totalAmountPaid = parseFloat(data.TongTienThue || 0) + parseFloat(data.TongTienCoc || 0);
            const amountToProcess = parseFloat(soTien || totalAmountPaid);

            // ĐÃ SỬA: Dùng MaKhachThue thay vì MaNguoiThue
            const [tenantWallet] = await conn.execute("SELECT MaVi FROM vi WHERE MaNguoiDung = ?", [data.MaKhachThue]);
            const [hostWallet] = await conn.execute("SELECT MaVi FROM vi WHERE MaNguoiDung = ?", [data.MaChuDo]);

            const customerWalletId = tenantWallet[0]?.MaVi;
            const hostWalletId = hostWallet[0]?.MaVi;

            if (hinhThucId == 1) {
                // [Hình thức 1]: Hoàn tiền cho Khách thuê
                await conn.execute("UPDATE vi SET SoTienDongBang = SoTienDongBang - ?, NgayCapNhat = NOW() WHERE MaVi = ?", [amountToProcess, systemWalletId]);
                await conn.execute("UPDATE vi SET SoDuKhaDung = SoDuKhaDung + ?, NgayCapNhat = NOW() WHERE MaVi = ?", [amountToProcess, customerWalletId]);
                
                await conn.execute(
                    `INSERT INTO giaodichvi (MaVi, MaViDoiTac, MaDonThue, LoaiGiaoDich, SoTien, TrangThai, NgayGiaoDich)
                     VALUES (?, ?, ?, 'HoanTien', ?, 'Thành công', NOW())`,
                    [customerWalletId, systemWalletId, orderId, amountToProcess]
                );

            } else if (hinhThucId == 2) {
                // [Hình thức 2]: Bồi thường cho Chủ đồ
                await conn.execute("UPDATE vi SET SoTienDongBang = SoTienDongBang - ?, NgayCapNhat = NOW() WHERE MaVi = ?", [amountToProcess, systemWalletId]);
                await conn.execute("UPDATE vi SET SoDuKhaDung = SoDuKhaDung + ?, NgayCapNhat = NOW() WHERE MaVi = ?", [amountToProcess, hostWalletId]);

                await conn.execute(
                    `INSERT INTO giaodichvi (MaVi, MaViDoiTac, MaDonThue, LoaiGiaoDich, SoTien, TrangThai, NgayGiaoDich)
                     VALUES (?, ?, ?, 'BoiThuong', ?, 'Thành công', NOW())`,
                    [hostWalletId, systemWalletId, orderId, amountToProcess]
                );

            } else if (hinhThucId == 3) {
                // [Hình thức 3]: Thỏa thuận 50 - 50
                const halfAmount = amountToProcess / 2;
                await conn.execute("UPDATE vi SET SoTienDongBang = SoTienDongBang - ?, NgayCapNhat = NOW() WHERE MaVi = ?", [amountToProcess, systemWalletId]);
                await conn.execute("UPDATE vi SET SoDuKhaDung = SoDuKhaDung + ?, NgayCapNhat = NOW() WHERE MaVi = ?", [halfAmount, customerWalletId]);
                await conn.execute("UPDATE vi SET SoDuKhaDung = SoDuKhaDung + ?, NgayCapNhat = NOW() WHERE MaVi = ?", [halfAmount, hostWalletId]);

                await conn.execute(
                    `INSERT INTO giaodichvi (MaVi, MaViDoiTac, MaDonThue, LoaiGiaoDich, SoTien, TrangThai, NgayGiaoDich)
                     VALUES (?, ?, ?, 'HoanTien', ?, 'Thành công', NOW()), (?, ?, ?, 'GiaiNgan', ?, 'Thành công', NOW())`,
                    [customerWalletId, systemWalletId, orderId, halfAmount, hostWalletId, systemWalletId, orderId, halfAmount]
                );
            }

            await conn.execute(
                `UPDATE khieunai 
                 SET MaHinhThucXuLy = ?, NgayGiaiQuyet = NOW(), SoTienTuongUng = ?, 
                     NoiDungChiTiet = ?, MaAdmin = ?, TrangThai = 'Đã giải quyết'
                 WHERE MaKhieuNai = ?`,
                [hinhThucId, amountToProcess, noiDung, adminId, complaintId]
            );

            await conn.execute(
                "UPDATE donthue SET TrangThaiDon = ? WHERE MaDonThue = ?",
                [trangThaiDonMoi || 'resolved', orderId]
            );

            await commitTransaction(conn);
            return true;

        } catch (error) {
            await rollbackTransaction(conn);
            throw new Error("Lỗi khi xử lý khiếu nại: " + error.message);
        }
    }

    static async getPendingComplaints() {
        const { execute } = await import("../config/db.js");
        const [rows] = await execute(
            `SELECT kn.*, nd.HoTen AS TenNguoiKhieuNai 
             FROM khieunai kn
             LEFT JOIN nguoidung nd ON kn.MaNguoiKhieuNai = nd.MaNguoiDung
             WHERE kn.TrangThai = 'Chờ xử lý'
             ORDER BY kn.NgayKhieuNai DESC`
        );
        return rows;
    }

    static async processPaymentEscrow(orderId, customerUserId, totalAmount) {
        const { beginTransaction, commitTransaction, rollbackTransaction } = await import("../config/db.js");
        const conn = await beginTransaction();

        try {
            const systemWalletId = 5; 

            const [customerWalletRows] = await conn.execute(
                "SELECT MaVi, SoDuKhaDung FROM vi WHERE MaNguoiDung = ? FOR UPDATE", 
                [customerUserId]
            );
            
            if (customerWalletRows.length === 0) {
                throw new Error("Không tìm thấy ví của khách hàng.");
            }
            
            const customerWallet = customerWalletRows[0];

            if (parseFloat(customerWallet.SoDuKhaDung) < parseFloat(totalAmount)) {
                throw new Error("Số dư khả dụng không đủ để thanh toán đơn hàng này.");
            }

            await conn.execute(
                "UPDATE vi SET SoDuKhaDung = SoDuKhaDung - ?, NgayCapNhat = NOW() WHERE MaVi = ?",
                [totalAmount, customerWallet.MaVi]
            );

            await conn.execute(
                "UPDATE vi SET SoTienDongBang = SoTienDongBang + ?, NgayCapNhat = NOW() WHERE MaVi = ?",
                [totalAmount, systemWalletId]
            );

            await conn.execute(
                `INSERT INTO giaodichvi (MaVi, MaViDoiTac, MaDonThue, LoaiGiaoDich, SoTien, TrangThai, NgayGiaoDich)
                 VALUES (?, ?, ?, 'ThanhToan', ?, 'Thành công', NOW())`,
                [customerWallet.MaVi, systemWalletId, orderId, totalAmount]
            );

            await conn.execute(
                `INSERT INTO giaodichvi (MaVi, MaViDoiTac, MaDonThue, LoaiGiaoDich, SoTien, TrangThai, NgayGiaoDich)
                 VALUES (?, ?, ?, 'NhanTamGiu', ?, 'Thành công', NOW())`,
                [systemWalletId, customerWallet.MaVi, orderId, totalAmount]
            );

            await conn.execute(
                "UPDATE donthue SET TrangThaiDon = 'paid' WHERE MaDonThue = ?",
                [orderId]
            );

            await commitTransaction(conn);
            return true;

        } catch (error) {
            await rollbackTransaction(conn);
            throw error;
        }
    }

    // =========================================================
    // 🛠️ ĐÃ SỬA: HOÀN TẤT ĐƠN HÀNG & GIẢI NGÂN (ESCROW PAYOUT)
    // =========================================================
    static async completeOrderAndPayout(orderId) {
        const { beginTransaction, commitTransaction, rollbackTransaction } = await import("../config/db.js");
        const conn = await beginTransaction();

        try {
            const systemWalletId = 5; 

            // ĐÃ SỬA: Dùng TongTienThue, TongTienCoc, MaKhachThue và MaChuSoHuu để truy vấn
            const [orderRows] = await conn.execute(
                `SELECT dt.MaDonThue, dt.MaKhachThue, dt.TongTienThue, dt.TongTienCoc, dt.TrangThaiDon,
                        sp.MaChuSoHuu AS MaChuDo
                 FROM donthue dt
                 JOIN chitietdonthue ct ON dt.MaDonThue = ct.MaDonThue
                 JOIN sanpham sp ON ct.MaSanPham = sp.MaSanPham
                 WHERE dt.MaDonThue = ? LIMIT 1 FOR UPDATE`,
                [orderId]
            );

            if (orderRows.length === 0) {
                throw new Error("Không tìm thấy đơn thuê!");
            }

            const order = orderRows[0];

            if (order.TrangThaiDon !== 'paid') {
                throw new Error("Đơn hàng chưa thanh toán hoặc đang trong trạng thái tranh chấp!");
            }

            const rentalFee = parseFloat(order.TongTienThue || 0); 
            const depositFee = parseFloat(order.TongTienCoc || 0); 
            const totalAmount = rentalFee + depositFee;

            // ĐÃ SỬA: Dùng MaKhachThue thay vì MaNguoiThue
            const [tenantWallet] = await conn.execute("SELECT MaVi FROM vi WHERE MaNguoiDung = ?", [order.MaKhachThue]);
            const [hostWallet] = await conn.execute("SELECT MaVi FROM vi WHERE MaNguoiDung = ?", [order.MaChuDo]);

            if (tenantWallet.length === 0 || hostWallet.length === 0) {
                throw new Error("Không tìm thấy thông tin ví của Khách thuê hoặc Chủ đồ!");
            }

            const customerWalletId = tenantWallet[0].MaVi;
            const hostWalletId = hostWallet[0].MaVi;

            // 3. Trừ SoTienDongBang của Ví Hệ Thống
            await conn.execute(
                "UPDATE vi SET SoTienDongBang = SoTienDongBang - ?, NgayCapNhat = NOW() WHERE MaVi = ?",
                [totalAmount, systemWalletId]
            );

            // 4. Cộng tiền thuê vào SoDuKhaDung của Chủ đồ
            await conn.execute(
                "UPDATE vi SET SoDuKhaDung = SoDuKhaDung + ?, NgayCapNhat = NOW() WHERE MaVi = ?",
                [rentalFee, hostWalletId]
            );

            // 5. Ghi lịch sử giải ngân cho Chủ đồ
            await conn.execute(
                `INSERT INTO giaodichvi (MaVi, MaViDoiTac, MaDonThue, LoaiGiaoDich, SoTien, TrangThai, NgayGiaoDich)
                 VALUES (?, ?, ?, 'GiaiNgan', ?, 'Thành công', NOW())`,
                [hostWalletId, systemWalletId, orderId, rentalFee]
            );

            // 6. Nếu có tiền cọc -> Hoàn tiền cọc lại vào SoDuKhaDung của Khách thuê
            if (depositFee > 0) {
                await conn.execute(
                    "UPDATE vi SET SoDuKhaDung = SoDuKhaDung + ?, NgayCapNhat = NOW() WHERE MaVi = ?",
                    [depositFee, customerWalletId]
                );

                await conn.execute(
                    `INSERT INTO giaodichvi (MaVi, MaViDoiTac, MaDonThue, LoaiGiaoDich, SoTien, TrangThai, NgayGiaoDich)
                     VALUES (?, ?, ?, 'HoanCoc', ?, 'Thành công', NOW())`,
                    [customerWalletId, systemWalletId, orderId, depositFee]
                );
            }

            // 7. Đổi trạng thái đơn thuê sang 'completed'
            await conn.execute(
                "UPDATE donthue SET TrangThaiDon = 'completed' WHERE MaDonThue = ?",
                [orderId]
            );

            await commitTransaction(conn);
            return true;

        } catch (error) {
            await rollbackTransaction(conn);
            throw error;
        }
    }
}