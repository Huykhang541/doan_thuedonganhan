
// import { execute } from "../config/db.js";

// export default class productModel {

//     // =========================================================================
//     // LINK 1: GET /products (Hiển thị trang chủ - ĐÃ THÊM LỌC CHỈ HIỆN SẢN PHẨM SẴN SÀNG)
//     // =========================================================================
//     static async allproduct() {
//         try {
//             const query = `
//                 SELECT 
//                     sp.MaSanPham AS id, 
//                     sp.TenSanPham AS name, 
//                     sp.MoTa AS description, 
//                     sp.GiaThueTheoNgay AS price,
//                     sp.DuongDanAnhHome AS DuongDanAnhHome, -- Lấy thẳng ảnh của sản phẩm gốc
//                     sp.DuongDanAnhHome AS image -- Backup thêm key image cho chắc ăn
//                 FROM sanpham sp
//                 WHERE sp.TrangThai = 'SanSang'
//             `;
//             const [rows] = await execute(query);
//             return rows; 
//         } catch (error) {
//             throw new Error("Lỗi lấy danh sách sản phẩm: " + error.message);
//         }
//     }

//     // =========================================================================
//     // LINK 2: GET /products/product-variants/get-all (Lấy toàn bộ biến thể)
//     // =========================================================================
//     static async getProductVariants() {
//         try {
//             const query = `
//                 SELECT 
//                     bt.MaBienThe AS id, 
//                     bt.MaSanPham AS product_id, 
//                     sp.TenSanPham AS name, 
//                     bt.MauSac AS color, 
//                     bt.DuongDanAnh AS image, 
//                     bt.SoLuongTonBienThe AS stock_quantity,
//                     sp.GiaThueTheoNgay AS price,
//                     sp.MaDanhMuc AS brandId -- Bổ sung dòng này để nối mã danh mục
//                 FROM bienthesanpham bt
//                 JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham
//                 ORDER BY bt.MaSanPham ASC
//             `;
//             const [rows] = await execute(query);
//             return rows;
//         } catch (error) {
//             throw new Error("Lỗi lấy danh sách biến thể: " + error.message);
//         }
//     }

//     // =========================================================================
//     // 3. Lấy chi tiết sản phẩm (API /products/:id)
//     // =========================================================================
//     static async findProductById(id){
//         try{
//             const queryProduct = `
//                 SELECT 
//                     sp.MaSanPham AS id, 
//                     sp.TenSanPham AS name, 
//                     sp.MoTa AS description,
//                     'Đồ cắm trại' as brand_name 
//                 FROM sanpham sp
//                 WHERE sp.MaSanPham = ?
//             `;
//             const [productRows] = await execute(queryProduct, [id]);
//             if (productRows.length === 0) return null;
//             const product = productRows[0];

//             const queryVariants = `
//                 SELECT 
//                     bt.MaBienThe AS id,
//                     bt.MaSanPham AS product_id,
//                     sp.GiaThueTheoNgay AS price,
//                     bt.SoLuongTonBienThe AS stock_quantity,
//                     bt.DuongDanAnh AS image,
//                     bt.MauSac AS color
//                 FROM bienthesanpham bt
//                 JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham
//                 WHERE bt.MaSanPham = ?
//             `;
//             const [variants] = await execute(queryVariants, [id]);
//             product.variants = variants; 
//             return product;
//         }catch(error){
//             throw new Error("Lỗi lấy chi tiết sản phẩm: " + error.message);
//         }
//     }

//     // =========================================================================
//     // 4. Tìm kiếm nâng cao (ĐÃ FIX: Trả về đúng cấu trúc Variant cho Flutter)
//     // =========================================================================
//     static async searchProduct(filters) {
//         try {
//             // Đã JOIN thêm bienthesanpham để App có ảnh và màu sắc
//             let sql = `
//                 SELECT 
//                     bt.MaBienThe AS id, 
//                     bt.MaSanPham AS product_id, 
//                     sp.TenSanPham AS name, 
//                     bt.MauSac AS color, 
//                     bt.DuongDanAnh AS image, 
//                     bt.SoLuongTonBienThe AS stock_quantity,
//                     sp.GiaThueTheoNgay AS price,
//                     sp.MaDanhMuc AS brandId,
//                     sp.TienCoc as deposit
//                 FROM bienthesanpham bt
//                 JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham
//                 WHERE sp.TrangThai = 'SanSang'
//             `;
//             const values = [];

//             if (filters.name) {
//                 sql += ` AND sp.TenSanPham LIKE ?`;
//                 values.push(`%${filters.name}%`);
//             }
//             if (filters.category_id) {
//                 sql += ` AND sp.MaDanhMuc = ?`;
//                 values.push(filters.category_id);
//             }
//             if (filters.min_price) {
//                 sql += ` AND sp.TienCoc >= ?`;
//                 values.push(filters.min_price);
//             }
//             if (filters.max_price) {
//                 sql += ` AND sp.TienCoc <= ?`;
//                 values.push(filters.max_price);
//             }
//             if (filters.min_rent_price) {
//                 sql += ` AND sp.GiaThueTheoNgay >= ?`;
//                 values.push(filters.min_rent_price);
//             }
//             if (filters.max_rent_price) {
//                 sql += ` AND sp.GiaThueTheoNgay <= ?`;
//                 values.push(filters.max_rent_price);
//             }

//             const [rows] = await execute(sql, values);
//             return rows;
//         } catch (error) {
//             throw new Error('Lỗi tìm kiếm sản phẩm: ' + error.message);
//         }
//     }

//     // =========================================================================
//     // 5. Lấy biến thể theo ID biến thể
//     // =========================================================================
//     static async findProductVariantById(variant_id){
//         try{
//             const [rows] = await execute(`
//                 SELECT 
//                     bt.MaBienThe AS id,
//                     bt.MaSanPham AS product_id,
//                     sp.GiaThueTheoNgay AS price,
//                     bt.SoLuongTonBienThe AS stock_quantity, 
//                     bt.DuongDanAnh AS image,
//                     bt.MauSac AS color
//                 FROM bienthesanpham bt
//                 JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham
//                 WHERE bt.MaBienThe = ?
//             `,[variant_id]);
            
//             if(rows.length === 0) throw new Error('Không tìm thấy variant_id');
//             return rows[0];
//         }
//         catch(error){
//             throw new Error('Lỗi lấy biến thể: ' + error.message)
//         }
//     }

//     // =========================================================================
//     // 6. Lấy danh sách biến thể theo ID sản phẩm
//     // =========================================================================
//     static async findProductVariantByProductID(product_id){
//         try{
//             const [rows] = await execute(`
//                 SELECT 
//                     bt.MaBienThe AS id, 
//                     sp.TenSanPham AS name, 
//                     sp.MoTa AS description, 
//                     bt.MaSanPham AS product_id, 
//                     sp.GiaThueTheoNgay AS price, 
//                     bt.SoLuongTonBienThe AS stock_quantity,  
//                     bt.DuongDanAnh AS image,
//                     bt.MauSac AS color
//                 FROM bienthesanpham bt
//                 JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham
//                 WHERE bt.MaSanPham = ?
//             `,[product_id]);
            
//             if(rows.length === 0) throw new Error('Không tìm thấy product_id');
//             return rows;
//         }
//         catch(error){
//             throw new Error('Lỗi lấy biến thể bằng product_id: ' + error.message);
//         }
//     }

//     // =========================================================================
//     // API CHỦ ĐỒ (LESSOR) - QUẢN LÝ SẢN PHẨM
//     // =========================================================================

//     // 1. Xem danh sách sản phẩm cá nhân (Chủ đồ luôn xem được mọi trạng thái bài đăng của mình)
//     static async getMyProducts(lessorId) {
//         try {
//             const query = `
//                 SELECT 
//                     sp.MaSanPham AS id, 
//                     sp.TenSanPham AS name, 
//                     sp.MoTa AS description, 
//                     sp.GiaThueTheoNgay AS price,
//                     sp.TrangThai AS status,
//                     sp.DuongDanAnhHome AS DuongDanAnhHome, -- Lấy ảnh gốc
//                     sp.DuongDanAnhHome AS image
//                 FROM sanpham sp
//                 WHERE sp.MaChuSoHuu = ?
//                 ORDER BY sp.MaSanPham DESC
//             `;
//             const [rows] = await execute(query, [lessorId]);
//             return rows;
//         } catch (error) {
//             throw new Error("Lỗi lấy danh sách sản phẩm của tôi: " + error.message);
//         }
//     }

//     // 2. Thêm mới sản phẩm (ĐÃ THÊM ÉP TRẠNG THÁI 'ChoDuyet' ĐỂ CHỜ ADMIN KIỂM DUYỆT)
//     static async createProduct(lessorId, productData) {
//         try {
//             const { name, price, deposit, description, category_id } = productData;
//             const query = `
//                 INSERT INTO sanpham (TenSanPham, GiaThueTheoNgay, TienCoc, MoTa, MaDanhMuc, MaChuSoHuu, TrangThai)
//                 VALUES (?, ?, ?, ?, ?, ?, 'ChoDuyet')
//             `;
//             const [result] = await execute(query, [name, price, deposit, description, category_id, lessorId]);
//             return result.insertId; 
//         } catch (error) {
//             throw new Error("Lỗi thêm sản phẩm: " + error.message);
//         }
//     }

//     // 3. Cập nhật thông tin sản phẩm
//     static async updateProduct(productId, lessorId, productData) {
//         try {
//             const { name, price, deposit, description, category_id } = productData;
//             const query = `
//                 UPDATE sanpham 
//                 SET TenSanPham = ?, GiaThueTheoNgay = ?, TienCoc = ?, MoTa = ?, MaDanhMuc = ?
//                 WHERE MaSanPham = ? AND MaChuSoHuu = ?
//             `;
//             const [result] = await execute(query, [name, price, deposit, description, category_id, productId, lessorId]);
//             return result.affectedRows > 0;
//         } catch (error) {
//             throw new Error("Lỗi cập nhật sản phẩm: " + error.message);
//         }
//     }

//     // 4. Xóa sản phẩm
//     static async deleteProduct(productId, lessorId) {
//         try {
//             const query = `DELETE FROM sanpham WHERE MaSanPham = ? AND MaChuSoHuu = ?`;
//             const [result] = await execute(query, [productId, lessorId]);
//             return result.affectedRows > 0;
//         } catch (error) {
//             throw new Error("Lỗi xóa sản phẩm: " + error.message);
//         }
//     }

//     // =========================================================================
//     // BỔ SUNG: MODEL ADMIN CẬP NHẬT TRẠNG THÁI KIỂM DUYỆT VÀO DATABASE
//     // =========================================================================
//     static async updateProductStatus(productId, status) {
//         try {
//             // Câu lệnh SQL đổi trạng thái dựa theo MaSanPham
//             const query = `UPDATE sanpham SET TrangThai = ? WHERE MaSanPham = ?`;
//             const [result] = await execute(query, [status, productId]);
            
//             // Trả về true nếu có hàng (row) bị tác động, ngược lại trả về false
//             return result.affectedRows > 0;
//         } catch (error) {
//             throw new Error("Lỗi cập nhật trạng thái kiểm duyệt sản phẩm: " + error.message);
//         }
//     }

//     // =========================================================================
//     // BỔ SUNG: MODEL ADMIN XÓA VĨNH VIỄN SẢN PHẨM KHỎI DATABASE
//     // =========================================================================
//     static async adminForceDeleteProduct(productId) {
//         try {
//             // Xóa trực tiếp sản phẩm khỏi bảng sanpham dựa trên MaSanPham
//             const query = `DELETE FROM sanpham WHERE MaSanPham = ?`;
//             const [result] = await execute(query, [productId]);
            
//             // Trả về true nếu có dòng dữ liệu bị xóa thành công
//             return result.affectedRows > 0;
//         } catch (error) {
//             // Lưu ý: Nếu bị lỗi Ràng buộc khóa ngoại (Foreign Key Constraint), 
//             // Database của bạn cần được set ON DELETE CASCADE ở các bảng con (như bienthesanpham, yeuthich...)
//             throw new Error("Lỗi khi xóa sản phẩm: " + error.message);
//         }
//     }
// }


import { execute } from "../config/db.js";

export default class productModel {

    // =========================================================================
    // 1. Hiển thị trang chủ (Lấy Sản Phẩm Gốc)
    // =========================================================================
    static async allproduct() {
        try {
            const query = `
                SELECT 
                    sp.MaSanPham AS id, 
                    sp.TenSanPham AS name, 
                    sp.MoTa AS description, 
                    sp.GiaThueTheoNgay AS price,
                    sp.DuongDanAnhHome AS DuongDanAnhHome, 
                    sp.DuongDanAnhHome AS image 
                FROM sanpham sp
                WHERE sp.TrangThai = 'SanSang'
            `;
            const [rows] = await execute(query);
            return rows; 
        } catch (error) {
            throw new Error("Lỗi lấy danh sách sản phẩm: " + error.message);
        }
    }

    // =========================================================================
    // 2. Lấy toàn bộ biến thể
    // =========================================================================
    static async getProductVariants() {
        try {
            const query = `
                SELECT 
                    bt.MaBienThe AS id, 
                    bt.MaSanPham AS product_id, 
                    sp.TenSanPham AS name, 
                    bt.MauSac AS color, 
                    bt.DuongDanAnh AS image, 
                    bt.SoLuongTonBienThe AS stock_quantity,
                    sp.GiaThueTheoNgay AS price,
                    sp.MaDanhMuc AS brandId 
                FROM bienthesanpham bt
                JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham
                ORDER BY bt.MaSanPham ASC
            `;
            const [rows] = await execute(query);
            return rows;
        } catch (error) {
            throw new Error("Lỗi lấy danh sách biến thể: " + error.message);
        }
    }

    // =========================================================================
    // 3. Lấy chi tiết sản phẩm 
    // =========================================================================
    static async findProductById(id){
        try{
            const queryProduct = `
                SELECT 
                    sp.MaSanPham AS id, 
                    sp.TenSanPham AS name, 
                    sp.MoTa AS description,
                    'Đồ cắm trại' as brand_name 
                FROM sanpham sp
                WHERE sp.MaSanPham = ?
            `;
            const [productRows] = await execute(queryProduct, [id]);
            if (productRows.length === 0) return null;
            const product = productRows[0];

            const queryVariants = `
                SELECT 
                    bt.MaBienThe AS id,
                    bt.MaSanPham AS product_id,
                    sp.GiaThueTheoNgay AS price,
                    bt.SoLuongTonBienThe AS stock_quantity,
                    bt.DuongDanAnh AS image,
                    bt.MauSac AS color
                FROM bienthesanpham bt
                JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham
                WHERE bt.MaSanPham = ?
            `;
            const [variants] = await execute(queryVariants, [id]);
            product.variants = variants; 
            return product;
        }catch(error){
            throw new Error("Lỗi lấy chi tiết sản phẩm: " + error.message);
        }
    }

    // =========================================================================
    // 4. Tìm kiếm & Lọc Sản phẩm (ĐÃ FIX: TRẢ VỀ SẢN PHẨM GỐC)
    // =========================================================================
    static async searchProduct(filters) {
        try {
            let sql = `
                SELECT 
                    sp.MaSanPham AS id, 
                    sp.TenSanPham AS name, 
                    sp.MoTa AS description, 
                    sp.GiaThueTheoNgay AS price,
                    sp.MaDanhMuc AS brandId,
                    sp.TienCoc as deposit,
                    sp.DuongDanAnhHome AS DuongDanAnhHome,
                    sp.DuongDanAnhHome AS image
                FROM sanpham sp
                WHERE sp.TrangThai = 'SanSang'
            `;
            const values = [];

            if (filters.name) {
                sql += ` AND sp.TenSanPham LIKE ?`;
                values.push(`%${filters.name}%`);
            }
            if (filters.category_id) {
                sql += ` AND sp.MaDanhMuc = ?`;
                values.push(filters.category_id);
            }
            if (filters.min_price) {
                sql += ` AND sp.TienCoc >= ?`;
                values.push(filters.min_price);
            }
            if (filters.max_price) {
                sql += ` AND sp.TienCoc <= ?`;
                values.push(filters.max_price);
            }
            if (filters.min_rent_price) {
                sql += ` AND sp.GiaThueTheoNgay >= ?`;
                values.push(filters.min_rent_price);
            }
            if (filters.max_rent_price) {
                sql += ` AND sp.GiaThueTheoNgay <= ?`;
                values.push(filters.max_rent_price);
            }

            const [rows] = await execute(sql, values);
            return rows;
        } catch (error) {
            throw new Error('Lỗi tìm kiếm sản phẩm: ' + error.message);
        }
    }

    // =========================================================================
    // 5. Lấy biến thể theo ID biến thể
    // =========================================================================
    static async findProductVariantById(variant_id){
        try{
            const [rows] = await execute(`
                SELECT bt.MaBienThe AS id, bt.MaSanPham AS product_id, sp.GiaThueTheoNgay AS price, bt.SoLuongTonBienThe AS stock_quantity, bt.DuongDanAnh AS image, bt.MauSac AS color FROM bienthesanpham bt JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham WHERE bt.MaBienThe = ?
            `,[variant_id]);
            if(rows.length === 0) throw new Error('Không tìm thấy variant_id');
            return rows[0];
        }
        catch(error){ throw new Error('Lỗi lấy biến thể: ' + error.message); }
    }

    // =========================================================================
    // 6. Lấy danh sách biến thể theo ID sản phẩm
    // =========================================================================
    static async findProductVariantByProductID(product_id){
        try{
            const [rows] = await execute(`
                SELECT bt.MaBienThe AS id, sp.TenSanPham AS name, sp.MoTa AS description, bt.MaSanPham AS product_id, sp.GiaThueTheoNgay AS price, bt.SoLuongTonBienThe AS stock_quantity, bt.DuongDanAnh AS image, bt.MauSac AS color FROM bienthesanpham bt JOIN sanpham sp ON bt.MaSanPham = sp.MaSanPham WHERE bt.MaSanPham = ?
            `,[product_id]);
            if(rows.length === 0) throw new Error('Không tìm thấy product_id');
            return rows;
        }
        catch(error){ throw new Error('Lỗi lấy biến thể bằng product_id: ' + error.message); }
    }

    // =========================================================================
    // API CHỦ ĐỒ & ADMIN
    // =========================================================================
    static async getMyProducts(lessorId) {
        try {
            const query = `
                SELECT 
                    sp.MaSanPham AS id, sp.TenSanPham AS name, sp.MoTa AS description, sp.GiaThueTheoNgay AS price, sp.TrangThai AS status,
                    sp.DuongDanAnhHome AS DuongDanAnhHome, sp.DuongDanAnhHome AS image
                FROM sanpham sp
                WHERE sp.MaChuSoHuu = ?
                ORDER BY sp.MaSanPham DESC
            `;
            const [rows] = await execute(query, [lessorId]);
            return rows;
        } catch (error) { throw new Error("Lỗi lấy danh sách sản phẩm của tôi: " + error.message); }
    }

    static async createProduct(lessorId, productData) {
        try {
            const { name, price, deposit, description, category_id } = productData;
            const query = `INSERT INTO sanpham (TenSanPham, GiaThueTheoNgay, TienCoc, MoTa, MaDanhMuc, MaChuSoHuu, TrangThai) VALUES (?, ?, ?, ?, ?, ?, 'ChoDuyet')`;
            const [result] = await execute(query, [name, price, deposit, description, category_id, lessorId]);
            return result.insertId; 
        } catch (error) { throw new Error("Lỗi thêm sản phẩm: " + error.message); }
    }

    static async updateProduct(productId, lessorId, productData) {
        try {
            const { name, price, deposit, description, category_id } = productData;
            const query = `UPDATE sanpham SET TenSanPham = ?, GiaThueTheoNgay = ?, TienCoc = ?, MoTa = ?, MaDanhMuc = ? WHERE MaSanPham = ? AND MaChuSoHuu = ?`;
            const [result] = await execute(query, [name, price, deposit, description, category_id, productId, lessorId]);
            return result.affectedRows > 0;
        } catch (error) { throw new Error("Lỗi cập nhật sản phẩm: " + error.message); }
    }

    static async deleteProduct(productId, lessorId) {
        try {
            const query = `DELETE FROM sanpham WHERE MaSanPham = ? AND MaChuSoHuu = ?`;
            const [result] = await execute(query, [productId, lessorId]);
            return result.affectedRows > 0;
        } catch (error) { throw new Error("Lỗi xóa sản phẩm: " + error.message); }
    }

    static async updateProductStatus(productId, status) {
        try {
            const query = `UPDATE sanpham SET TrangThai = ? WHERE MaSanPham = ?`;
            const [result] = await execute(query, [status, productId]);
            return result.affectedRows > 0;
        } catch (error) { throw new Error("Lỗi cập nhật trạng thái kiểm duyệt sản phẩm: " + error.message); }
    }

    static async adminForceDeleteProduct(productId) {
        try {
            const query = `DELETE FROM sanpham WHERE MaSanPham = ?`;
            const [result] = await execute(query, [productId]);
            return result.affectedRows > 0;
        } catch (error) { throw new Error("Lỗi khi xóa sản phẩm: " + error.message); }
    }
}