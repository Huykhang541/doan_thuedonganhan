import { execute } from '../config/db.js';

export default class favoriteModel {
    static async getFavoriteByUserID(user_id) {
        try {
            const query = `
                SELECT 
                    f.MaYeuThich, 
                    f.MaSanPham as product_variant_id, 
                    p.MaSanPham as product_id, 
                    p.TenSanPham as name, 
                    pv.MauSac as color, 
                    p.GiaThueTheoNgay as price, 
                    pv.DuongDanAnh as image 
                FROM yeuthich f
                JOIN bienthesanpham pv ON f.MaSanPham = pv.MaBienThe
                JOIN sanpham p ON pv.MaSanPham = p.MaSanPham
                WHERE f.MaNguoiDung = ?
            `;
            const [favorites] = await execute(query, [user_id]);
            return favorites.length === 0 ? [] : favorites;
        } catch (error) {
            throw new Error('Lỗi lấy sản phẩm ưa thích: ' + error.message);
        }
    }

    static async addFavorite(user_id, product_variant_id) {
        try {
            // Kiểm tra biến thể sản phẩm có tồn tại không
            const [product] = await execute('SELECT * FROM bienthesanpham WHERE MaBienThe = ?', [product_variant_id]);
            if (product.length === 0) {
                throw new Error('Không tìm thấy biến thể sản phẩm này');
            }

            // Kiểm tra xem đã thả tim chưa để tránh trùng lặp
            const [existing] = await execute('SELECT MaYeuThich FROM yeuthich WHERE MaNguoiDung = ? AND MaSanPham = ?', [user_id, product_variant_id]);
            if (existing.length > 0) return existing[0].MaYeuThich; // Đã sửa lỗi .id thành .MaYeuThich

            const [result] = await execute(
                'INSERT INTO yeuthich (MaNguoiDung, MaSanPham, NgayThem) VALUES (?, ?, NOW())',
                [user_id, product_variant_id]
            );
            return result.affectedRows > 0 ? result.insertId : null;
        } catch (error) {
            throw new Error('Lỗi thêm sản phẩm yêu thích: ' + error.message);
        }
    }

    static async removeFavorite(user_id, product_variant_id) {
        try {
            const [result] = await execute(
                'DELETE FROM yeuthich WHERE MaNguoiDung = ? AND MaSanPham = ?', 
                [user_id, product_variant_id]
            );
            if (result.affectedRows === 0) {
                throw new Error('Không tìm thấy sản phẩm ưa thích này để xóa');
            }
            return true;
        } catch (error) {
            throw new Error('Lỗi xóa sản phẩm ưa thích: ' + error.message);
        }
    }
}