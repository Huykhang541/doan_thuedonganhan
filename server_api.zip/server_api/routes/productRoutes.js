import { Router } from "express";
import productController from "../controllers/productController.js";
import auth from "../middleware/auth.js";

const productRoute = Router();

/**
 * @swagger
 * tags:
 *   - name: Products
 *     description: API sản phẩm cho thuê
 */

// =========================================================================
// API CHUNG (KHÔNG CẦN ĐĂNG NHẬP)
// =========================================================================

/**
 * @swagger
 * /products:
 *   get:
 *     summary: Lấy danh sách tất cả sản phẩm
 *     tags: [Products]
 *     responses:
 *       200:
 *         description: Thành công
 */
productRoute.get("/", productController.products);

/**
 * @swagger
 * /products/search:
 *   get:
 *     summary: Tìm kiếm sản phẩm theo tên
 *     tags: [Products]
 *     parameters:
 *       - in: query
 *         name: q
 *         required: true
 *         schema:
 *           type: string
 *         example: Lều
 *     responses:
 *       200:
 *         description: Tìm thấy sản phẩm
 */
productRoute.get("/search", productController.searchProduct);

/**
 * @swagger
 * /products/product-variants/get-all:
 *   get:
 *     summary: Lấy tất cả biến thể sản phẩm
 *     tags: [Products]
 *     responses:
 *       200:
 *         description: Thành công
 */
productRoute.get("/product-variants/get-all", productController.getAllProductVariant);

/**
 * @swagger
 * /products/product-variants/{product_id}:
 *   get:
 *     summary: Lấy biến thể của sản phẩm
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: product_id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Thành công
 */
productRoute.get("/product-variants/:product_id", productController.getProductVariantByProductId);


// =========================================================================
// API DÀNH CHO CHỦ ĐỒ (LESSOR) - CÓ BẢO MẬT BẰNG AUTH
// =========================================================================

/**
 * @swagger
 * /products/lessor/my-products:
 *   get:
 *     summary: Chủ đồ - Lấy danh sách sản phẩm của tôi
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Thành công
 */
productRoute.get("/lessor/my-products", auth, productController.getMyProducts);

/**
 * @swagger
 * /products/lessor/create:
 *   post:
 *     summary: Chủ đồ - Thêm sản phẩm mới
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               price:
 *                 type: number
 *               deposit:
 *                 type: number
 *               description:
 *                 type: string
 *               category_id:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Thêm thành công
 */
productRoute.post("/lessor/create", auth, productController.createProduct);

/**
 * @swagger
 * /products/lessor/update/{id}:
 *   put:
 *     summary: Chủ đồ - Cập nhật sản phẩm
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               price:
 *                 type: number
 *               deposit:
 *                 type: number
 *               description:
 *                 type: string
 *               category_id:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Cập nhật thành công
 */
productRoute.put("/lessor/update/:id", auth, productController.updateProduct);

/**
 * @swagger
 * /products/lessor/delete/{id}:
 *   delete:
 *     summary: Chủ đồ - Xóa sản phẩm
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Xóa thành công
 */
productRoute.delete("/lessor/delete/:id", auth, productController.deleteProduct);


// =========================================================================
// LƯU Ý: HÀM LẤY CHI TIẾT THEO ID PHẢI NẰM Ở DƯỚI CÙNG 
// =========================================================================

/**
 * @swagger
 * /products/{id}:
 *   get:
 *     summary: Xem chi tiết sản phẩm
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Thành công
 */
productRoute.get("/:id", productController.detailProduct);

export default productRoute;