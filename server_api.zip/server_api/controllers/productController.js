import productModel from '../models/productModel.js';

export default class productController{
    static async products(req,res){
        try{
            const products = await productModel.allproduct();

            return res.status(200).json({
                succeeded: true,
                products: products
            });
        }catch(error){
            return res.status(500).json({
                succeeded: false,
                message: error.message
            });
        }
    }
    
    static async searchProduct(req, res) {
        try {
            // Lấy các điều kiện lọc từ query (URL)
            const { name, min_price, max_price, category_id, min_rent_price, max_rent_price } = req.query;
            
            // Đẩy xuống Model để xử lý
            const products = await productModel.searchProduct({
                name, min_price, max_price, category_id, min_rent_price, max_rent_price
            });

            return res.status(200).json({
                succeeded: true,
                message: "Tìm kiếm sản phẩm thành công",
                products: products
            });
        } catch (error) {
            return res.status(500).json({ succeeded: false, message: error.message });
        }
    }

    static async detailProduct(req,res){
        try{
            const {id} = req.params;
            if(!id) return res.status(400).json({succeeded: false,message: "ID sản phẩm không được để trống"});
            const product = await productModel.findProductById(id);
            if(!product) return res.status(404).json({succeeded: false,message: "ID sản phẩm không tồn tại"});
            return res.status(200).json({succeeded: true,message: "Lấy chi tiết sản phẩm thành công", product: product});
        }
        catch(error){
            return res.status(500).json({succeeded: false,message: error.message});
        }
    }

    static async getProductVariantByProductId(req,res){
        try{
            const {product_id} = req.params;
            if(!product_id) return res.status(400).json({succeeded: false, message: "Thiếu id sản phẩm"});

            const products = await productModel.findProductVariantByProductID(product_id);
            
            return res.status(200).json({
                succeeded: true,
                message: "Lấy danh sách biến thể sản phẩm thành công",
                product_variants: products
            });
        }
        catch(error){
            return res.status(500).json({
                succeeded: false,
                message: error.message
            });
        }
    }

    static async getAllProductVariant(req,res){
        try{
            const product_variant = await productModel.getProductVariants();

            return res.status(200).json({
                succeeded: true,
                product_variants: product_variant
            });
        }
        catch(error){
            return res.status(500).json({
                succeeded: false,
                message: error.message
            });
        }
    }

    // =========================================================================
    // CONTROLLER: CHỦ ĐỒ (LESSOR) - QUẢN LÝ SẢN PHẨM 
    // =========================================================================

    static async getMyProducts(req, res) {
        try {
            // Lấy ID người dùng từ token đã xác thực
            const userId = req.user.id || req.user.userId || req.user.MaNguoiDung; 
            const products = await productModel.getMyProducts(userId);
            return res.status(200).json({
                succeeded: true,
                message: "Lấy danh sách sản phẩm của tôi thành công",
                products: products
            });
        } catch (error) {
            return res.status(500).json({ succeeded: false, message: error.message });
        }
    }

    static async createProduct(req, res) {
        try {
            const userId = req.user.id || req.user.userId || req.user.MaNguoiDung;
            const productData = req.body;
            
            const newProductId = await productModel.createProduct(userId, productData);
            return res.status(201).json({
                succeeded: true,
                message: "Thêm sản phẩm thành công",
                product_id: newProductId
            });
        } catch (error) {
            return res.status(500).json({ succeeded: false, message: error.message });
        }
    }

    static async updateProduct(req, res) {
        try {
            const userId = req.user.id || req.user.userId || req.user.MaNguoiDung;
            const productId = req.params.id;
            const productData = req.body;

            const isUpdated = await productModel.updateProduct(productId, userId, productData);
            if (!isUpdated) {
                return res.status(403).json({ succeeded: false, message: "Không thể cập nhật (Sản phẩm không tồn tại hoặc bạn không có quyền)" });
            }

            return res.status(200).json({ succeeded: true, message: "Cập nhật sản phẩm thành công" });
        } catch (error) {
            return res.status(500).json({ succeeded: false, message: error.message });
        }
    }

    static async deleteProduct(req, res) {
        try {
            const userId = req.user.id || req.user.userId || req.user.MaNguoiDung;
            const productId = req.params.id;

            const isDeleted = await productModel.deleteProduct(productId, userId);
            if (!isDeleted) {
                return res.status(403).json({ succeeded: false, message: "Không thể xóa (Sản phẩm không tồn tại hoặc bạn không có quyền)" });
            }

            return res.status(200).json({ succeeded: true, message: "Xóa sản phẩm thành công" });
        } catch (error) {
            return res.status(500).json({ succeeded: false, message: error.message });
        }
    }

    // =========================================================================
    // BỔ SUNG: CONTROLLER XỬ LÝ DUYỆT SẢN PHẨM CỦA ADMIN
    // =========================================================================
    static async approveProduct(req, res) {
        try {
            const productId = req.params.productId;
            const { status } = req.body; // Lấy 'SanSang' hoặc 'TuChoi' từ client gửi lên

            // Kiểm tra giá trị hợp lệ đầu vào
            if (!status || !['SanSang', 'TuChoi'].includes(status)) {
                return res.status(400).json({ 
                    succeeded: false, 
                    message: "Trạng thái không hợp lệ! Chỉ chấp nhận 'SanSang' hoặc 'TuChoi'." 
                });
            }

            // Gọi xuống Model để cập nhật vào database
            const isUpdated = await productModel.updateProductStatus(productId, status);
            
            if (!isUpdated) {
                return res.status(404).json({ 
                    succeeded: false, 
                    message: "Không tìm thấy sản phẩm hoặc cập nhật thất bại." 
                });
            }

            return res.status(200).json({
                succeeded: true,
                message: status === 'SanSang' ? "Đã duyệt và hiển thị sản phẩm lên trang chủ!" : "Đã từ chối bài đăng sản phẩm này!"
            });
        } catch (error) {
            return res.status(500).json({ succeeded: false, message: error.message });
        }
    }


    // =========================================================================
    // BỔ SUNG: CONTROLLER ADMIN XÓA SẢN PHẨM VI PHẠM
    // =========================================================================
    static async adminDeleteProduct(req, res) {
        try {
            const productId = req.params.productId;

            // Gọi xuống Model để xóa khỏi database
            const isDeleted = await productModel.adminForceDeleteProduct(productId);
            
            if (!isDeleted) {
                return res.status(404).json({ 
                    succeeded: false, 
                    message: "Không tìm thấy sản phẩm hoặc sản phẩm này đã bị xóa từ trước." 
                });
            }

            return res.status(200).json({
                succeeded: true,
                message: "Đã xóa vĩnh viễn sản phẩm vi phạm khỏi hệ thống!"
            });
        } catch (error) {
            return res.status(500).json({ succeeded: false, message: error.message });
        }
    }

}